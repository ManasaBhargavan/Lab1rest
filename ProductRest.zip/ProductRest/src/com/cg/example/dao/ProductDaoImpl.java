package com.cg.example.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.example.beans.Product;
import com.cg.example.staticdb.ProductDB;

public class ProductDaoImpl implements IProductDAO {

	static HashMap<Integer, Product> productIdMap = ProductDB.getProductIdMap();
	@Override
	public List<Product> getAllProducts() {
		List<Product> products = new ArrayList<Product>(productIdMap.values());
		return products;
	}

	@Override
	public Product getProduct(int productId) {
		Product product = productIdMap.get(productId);
		return product;
	}

	@Override
	public Product addProduct(Product product) {
		productIdMap.put(product.getProductId(), product);
		return product;
	}

	@Override
	public Product deleteProduct(int productId) {
		return productIdMap.remove(productId);
	}

}
