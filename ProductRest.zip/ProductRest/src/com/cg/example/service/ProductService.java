package com.cg.example.service;

import java.util.List;

import com.cg.example.beans.Product;
import com.cg.example.dao.IProductDAO;
import com.cg.example.dao.ProductDaoImpl;

public class ProductService implements IProductService {

	IProductDAO dao;

	
	public ProductService() {
		
		dao = new ProductDaoImpl();
	}

	
	public List<Product> getAllProducts() {
		return dao.getAllProducts();
	}

	
	public Product getProduct(int productId) {
		return dao.getProduct(productId);
	}

	
	public Product addProduct(Product product) {
		return dao.addProduct(product);
	}

	
	public Product deleteProduct(int productId) {
		return dao.deleteProduct(productId);
	}

}
