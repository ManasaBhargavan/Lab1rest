package com.cg.example.controller;

import java.util.List;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.cg.example.beans.Product;
import com.cg.example.service.IProductService;
import com.cg.example.service.ProductService;


@Path("/products")
public class ProductController {
	
	IProductService productservice;
	
	public ProductController() {
		productservice = new ProductService();
	}


	@GET
	@Path("/list")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> getProducts(){
		
		List<Product> listOfProducts = productservice.getAllProducts();
		return listOfProducts;
	}
	
	
	@POST
	@Path("/get")
	@Produces(MediaType.APPLICATION_JSON)
	public Product getProductById(@PathParam("productId") int productId){
		return productservice.getProduct(productId);
	}
	
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public Product addProduct(@FormParam("productId")int productId,@FormParam("productName")String productName,@FormParam("productPrice")double productPrice){
		Product product=new Product();
		product.setProductId(productId);
		product.setProductName(productName);
		product.setProductPrice(productPrice);
		return productservice.addProduct(product);
	}
	
	
	@POST
	@Path("/delete")
	@Produces(MediaType.APPLICATION_JSON)
	public Product deleteProduct(@FormParam("productId")int productId){
		Product product=productservice.deleteProduct(productId);
		if(product!=null){
			return product;
		}
		else{
			return new Product();
		}
	}

}
