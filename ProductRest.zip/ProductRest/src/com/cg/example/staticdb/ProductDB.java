package com.cg.example.staticdb;

import java.util.HashMap;

import com.cg.example.beans.Product;

public class ProductDB {

static HashMap<Integer, Product> productIdMap = getProductIdMap();
	
	static {
		if (productIdMap == null) {
			productIdMap = new HashMap<Integer, Product>();
			Product ipadproduct = new Product(1, "IPad", 67683.6);
			Product androidproduct = new Product(4, "Android", 20000.0);
			
			productIdMap.put(1, ipadproduct);
			productIdMap.put(2, androidproduct);
			
		}
}

	public static HashMap<Integer, Product> getProductIdMap() {
		// TODO Auto-generated method stub
		return productIdMap;
	}
}