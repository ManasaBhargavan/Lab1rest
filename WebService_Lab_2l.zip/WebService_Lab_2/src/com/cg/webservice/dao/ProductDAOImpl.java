package com.cg.webservice.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.webservice.beans.Product;
import com.cg.webservice.staticdb.ProductDB;

public class ProductDAOImpl implements IProductDAO {

	
	static HashMap<Integer, Product> productIdMap = ProductDB.getproductNameMap();
	
	@Override
	public List<Product> getAllProducts() {
		List<Product> products = new ArrayList<Product>(productIdMap.values());
		return products;
	}

	@Override
	public Product addProduct(Product product) {
		
		productIdMap.put(product.getId(), product);
		return product;
	}
}
