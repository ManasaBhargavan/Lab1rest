package com.cg.webservice.controller;

import java.util.List;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.cg.webservice.beans.Product;
import com.cg.webservice.service.IProductService;
import com.cg.webservice.service.ProductServiceImpl;

@Path("/products")
public class ProductController {

	IProductService productService;

	public ProductController() {
		productService = new ProductServiceImpl();
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> getProducts() {
		List<Product> listOfProducts = productService.getAllProducts();
		return listOfProducts;
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public Product addProduct(@FormParam("txtId") int txtId,
			@FormParam("txtName") String txtName,
			@FormParam("txtPrice") double txtPrice) {
		Product product = new Product();
		product.setId(txtId);
		product.setProductName(txtName);
		product.setPrice(txtPrice);
		
		return productService.addProduct(product);
	}
	
}
