package com.cg.webservice.service;

import java.util.List;

import com.cg.webservice.beans.Product;
import com.cg.webservice.dao.IProductDAO;
import com.cg.webservice.dao.ProductDAOImpl;

public class ProductServiceImpl implements IProductService {

	IProductDAO productDao = new ProductDAOImpl();
	
	@Override
	public List<Product> getAllProducts() {
		
		return productDao.getAllProducts();
	}

	@Override
	public Product addProduct(Product product) {
		
		return productDao.addProduct(product);
	}

}
