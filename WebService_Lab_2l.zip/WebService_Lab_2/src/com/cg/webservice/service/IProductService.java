package com.cg.webservice.service;

import java.util.List;

import com.cg.webservice.beans.Product;

public interface IProductService {

	public List<Product> getAllProducts();
	public Product addProduct(Product product);
}
