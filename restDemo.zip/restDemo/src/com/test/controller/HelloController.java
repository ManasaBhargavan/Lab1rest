package com.test.controller;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/hello")
public class HelloController
{
	@Path("/{empid}")
	@GET
	@Produces(MediaType.TEXT_HTML)
	public String searchEmployee(@PathParam("empid") int id)
	{
		return("<h1>Hello from REST ID= "+id+"</h1>");
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public Employee insertEmployee(@FormParam("id") int id)
	{
		Employee emp=new Employee(id,"John",9000);
		return emp;
	}
}
